• Project Description :
- This project builds a machine learning model to predict house prices using features such as:

GrLivArea (living area)
OverallQual (overall quality)
YearBuilt (year built)
TotalBsmtSF (basement area)
LotArea (lot area)
rooms (number of rooms)
Neighborhood
SaleType
SaleCondition

The model uses a Pipeline that includes data preprocessing and a Linear Regression model.

Project Structure

train.py                      # Train the model and save it

predict.py                    # Load model and predict new data

use_model.py                  # Example usage (prediction and evaluation)

train.csv                     # Training dataset

test.csv                      # Testing dataset 

house_price_pipeline.joblib   # Saved trained model (created after training)

README.txt                    # Project description 


• How to Use :

- Train the model , Run (train.py) This will:
+ read train.csv
+ train the model
+ save it as house_price_pipeline.joblib

-Load the  model to Predict new data Run predict.py

- predicting the test dataset and evaluate the model Run use_model.py This will:
+ load the saved model
+ predict house prices for test dataset or any other new dataset
+evaluate results (if actual prices are provided)



• How It Works :
- The model uses a Pipeline:
+ Numeric features are scaled using StandardScaler
+ Categorical features are encoded using OneHotEncoder
+ The processed data is passed to a LinearRegression model

• Evaluation Metrics :

- If test data includes SalePrice, the model can compute:
RMSE (Root Mean Squared Error)
R2 Score
Error Percentage


Note:

- Unknown categories are handled automatically by the encoder


• This project demonstrates:

- Data preprocessing
- One-hot encoding
- Machine learning pipelines
- Model training and saving
- Loading and predicting on new data